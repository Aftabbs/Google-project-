This is first individual project created  using Python it consists of a Google search tool.
created by importing Googlesearch and then assigning it to a variable(s) and then creating a new variable(keywords) and assign input ('enter your query:').
again create a variable(result) to store (s) and then add(keywords,6) # 6 is the output of the links which will be shown.

now create a for loop for result
and then print